import React, { useState, useEffect, useRef } from 'react';
import './App.css';

// --- DATA KONTEN (SUDAH DIANA SIAPKAN SEMUA) ---

// Galeri Foto Pilihan (8 Foto)
const photoGallery = [
  "https://images.pexels.com/photos/1761279/pexels-photo-1761279.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1", // Hutan berkabut
  "https://images.pexels.com/photos/3225517/pexels-photo-3225517.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1", // Pantai tropis
  "https://images.pexels.com/photos/2387873/pexels-photo-2387873.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1", // Jalan di malam hari
  "https://images.pexels.com/photos/1528640/pexels-photo-1528640.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1", // Orang di depan cahaya
  "https://images.pexels.com/photos/3408744/pexels-photo-3408744.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1", // Aurora
  "https://images.pexels.com/photos/268941/pexels-photo-268941.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1", // Lampu kota bokeh
  "https://images.pexels.com/photos/3293148/pexels-photo-3293148.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1", // Ayunan di pantai senja
  "https://images.pexels.com/photos/998641/pexels-photo-998641.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"  // Terowongan cahaya abstrak
];

// Lirik Lagu "Solo" - Clean Bandit ft. Demi Lovato (dengan penanda waktu)
const synchronizedLyrics = [
    { time: 14.5, text: "It's solo, solo, everybody" },
    { time: 18.0, text: "It's solo, e-e-e-everybody" },
    { time: 21.5, text: "It's solo, solo, everybody" },
    { time: 25.0, text: "I do it solo" },
    { time: 28.5, text: "I've been on my own since you left" },
    { time: 32.0, text: "I'm on the prowl, you're not around" },
    { time: 35.5, text: "I've been kinda lost without you" },
    { time: 39.0, text: "I'm on the prowl, I'm not around" },
    { time: 42.5, text: "I'm feeling it, I'm feeling it" },
    { time: 46.0, text: "I'm feeling it, I'm feeling it low" },
    { time: 49.5, text: "I don't wanna be, I don't wanna be" },
    { time: 53.0, text: "I don't wanna be, I don't wanna be alone, yo" },
    { time: 56.5, text: "I've been on my own since you left" },
    { time: 60.0, text: "I'm on the prowl, you're not around" },
    { time: 63.5, text: "I've been kinda lost without you" },
    { time: 67.0, text: "I'm on the prowl, I'm not around" },
    { time: 70.0, text: "Since you've been gone, I've been dancing on my own" },
    { time: 74.0, text: "This boy's a gun, I'm not a fool" },
    { time: 77.0, text: "I've been on my own, I've been on my own, oh god" },
    { time: 80.5, text: "I'm a, I'm a, I'm a mess in a dress" },
    { time: 84.0, text: "But I'm a, I'm a, I'm a mess in a dress" },
    { time: 87.5, text: "But I'm a, I'm a, I'm a mess in a dress" },
    { time: 91.0, text: "But I'm a, I'm a, I'm a mess in a dress" },
    { time: 94.5, text: "I'm a, I'm a, I'm a mess in a dress" },
];

function App() {
  const [currentPhoto, setCurrentPhoto] = useState(0);
  const [activeLyricIndex, setActiveLyricIndex] = useState(-1);
  const [isLoaded, setIsLoaded] = useState(false);
  const audioRef = useRef(null);

  // Efek untuk memulai semuanya saat halaman dimuat
  useEffect(() => {
    // Tunda sedikit untuk efek dramatis
    const loadTimer = setTimeout(() => {
      setIsLoaded(true);
      if(audioRef.current) {
        audioRef.current.play().catch(error => {
          console.error("Autoplay diblokir, perlu interaksi pengguna untuk memulai musik.");
        });
      }
    }, 2000); // Tampilkan layar loading selama 2 detik

    // Ganti foto setiap 7 detik
    const photoInterval = setInterval(() => {
      setCurrentPhoto(prev => (prev + 1) % photoGallery.length);
    }, 7000);

    return () => {
      clearTimeout(loadTimer);
      clearInterval(photoInterval);
    };
  }, []);

  // Efek untuk sinkronisasi lirik
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const onTimeUpdate = () => {
      const currentTime = audio.currentTime;
      const newLyricIndex = synchronizedLyrics.findIndex((lyric, index) => {
        const nextLyric = synchronizedLyrics[index + 1];
        return currentTime >= lyric.time && (!nextLyric || currentTime < nextLyric.time);
      });
      if (newLyricIndex !== activeLyricIndex) {
        setActiveLyricIndex(newLyricIndex);
      }
    };
    audio.addEventListener('timeupdate', onTimeUpdate);
    return () => audio.removeEventListener('timeupdate', onTimeUpdate);
  }, [activeLyricIndex]);

  return (
    <div className={`app-container ${isLoaded ? 'loaded' : ''}`}>
      <div className="loading-screen">
        <div className="spinner"></div>
        <p>Mempersiapkan Ruang Memori...</p>
      </div>

      <div className="background-particles">
        {[...Array(30)].map((_, i) => <div key={i} className="particle"></div>)}
      </div>

      <div className="content-card">
        <div className="photo-container">
          {photoGallery.map((photo, index) => (
            <img 
              key={photo}
              src={photo}
              alt="Memory"
              className={index === currentPhoto ? 'active' : ''}
            />
          ))}
          <div className="photo-overlay"></div>
        </div>
        
        <div className="lyrics-container">
            <div className="lyrics-scroll" style={{ transform: `translateY(-${Math.max(0, activeLyricIndex - 1) * 40}px)` }}>
                {synchronizedLyrics.map((lyric, index) => (
                    <p key={index} className={`lyric-line ${index === activeLyricIndex ? 'active' : ''}`}>
                        {lyric.text}
                    </p>
                ))}
            </div>
        </div>
      </div>
      
      <audio 
        ref={audioRef} 
        src="https://youtu.be/HrLlLClqTN0?si=g4PzVW-gLA_S4-9s" 
        loop 
      />
    </div>
  );
}

export default App;
